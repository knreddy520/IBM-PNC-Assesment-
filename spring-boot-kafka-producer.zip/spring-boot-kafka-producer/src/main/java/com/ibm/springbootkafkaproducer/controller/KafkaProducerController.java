package com.ibm.springbootkafkaproducer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.springbootkafkaproducer.service.KafkaSender;
import com.springboot.springbootkafkaproducer.model.AccountBalance;
import com.springboot.springbootkafkaproducer.model.AccountTransaction;

@RestController
@RequestMapping("/kafkaProducer")
public class KafkaProducerController {

	@Autowired
	private KafkaSender sender;
	
	@RequestMapping(method=RequestMethod.POST,value="/balance")
	public ResponseEntity<String> sendBalanceData(@RequestBody AccountBalance balance){
		sender.sendData(balance);
		return new ResponseEntity<>("Data sent to Kafka", HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/transaction")
	public ResponseEntity<String> sendTransactionData(@RequestBody AccountTransaction transaction){
		sender.sendData(transaction);
		return new ResponseEntity<>("Data sent to Kafka", HttpStatus.OK);
	}
	
}
