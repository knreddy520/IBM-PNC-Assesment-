package com.springboot.springbootkafkaproducer.model;

import java.time.LocalDateTime;

public class AccountTransaction {
	
	private String accountNumber;
	
	private LocalDateTime transactionTs;
	
	private String type;
	
	private long amount;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public LocalDateTime getTransactionTs() {
		return transactionTs;
	}

	public void setTransactionTs(LocalDateTime transactionTs) {
		this.transactionTs = transactionTs;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "AccountBalance [accountNumber=" + accountNumber + ", transactionTs=" + transactionTs + ", type=" + type
				+ ", amount=" + amount + "]";
	}
	
	


}
