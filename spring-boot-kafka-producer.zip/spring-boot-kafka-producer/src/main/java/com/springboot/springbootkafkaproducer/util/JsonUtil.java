package com.springboot.springbootkafkaproducer.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public class JsonUtil {
	
	
	public static String convertoJson(Object obj)
	{
		String jsonResult=null;
		
		if ( null != obj)
		{
			
							
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.registerModule(new JavaTimeModule());
			objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
			
			try {
				jsonResult = objectMapper.writeValueAsString(obj);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Exception while converting POJO to JSON:"+e.getMessage());
			}
		}
		
		return jsonResult;
	}
	

}
