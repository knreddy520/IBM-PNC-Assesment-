package com.springboot.springbootkafkaproducer.model;

import java.time.LocalDateTime;

public class AccountBalance {
	
	
	private String acctNum;
	
	private LocalDateTime lastUpdateTimestamp;
	
	private Long balance;

	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

	public LocalDateTime getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(LocalDateTime lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	public Long getBalance() {
		return balance;
	}

	public void setBalance(Long balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "AccountBalance [acctNum=" + acctNum + ", lastUpdateTimestamp=" + lastUpdateTimestamp + ", balance="
				+ balance + "]";
	}
	
	
	
}
