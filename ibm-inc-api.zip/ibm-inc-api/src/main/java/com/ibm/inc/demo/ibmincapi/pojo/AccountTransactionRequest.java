package com.ibm.inc.demo.ibmincapi.pojo;

import java.time.LocalDateTime;

public class AccountTransactionRequest {
	
	private String accountNumer;
		
	private LocalDateTime fromDate;
		
	private LocalDateTime toDate;
	
	private String transactionType;
	
	
	public String getAccountNumer() {
		return accountNumer;
	}

	public void setAccountNumer(String accountNumer) {
		this.accountNumer = accountNumer;
	}

	public LocalDateTime getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDateTime fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDateTime getToDate() {
		return toDate;
	}

	public void setToDate(LocalDateTime toDate) {
		this.toDate = toDate;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "AccountTransactionRequest [accountNumer=" + accountNumer + ", fromDate=" + fromDate + ", toDate="
				+ toDate + ", transactionType=" + transactionType + "]";
	}
		
	
	
}
