package com.ibm.inc.demo.ibmincapi.pojo;

import java.util.List;

import com.ibm.inc.demo.ibmincapi.entity.AccountTransactionDetails;

public class AccountTransactionResponse {
	
	
	private List<AccountTransactionDetails> transactionsList;
	
	private int totalPages;
	
	private Long totalElements;
	
	private int currentPage;
	

	public List<AccountTransactionDetails> getTransactionsList() {
		return transactionsList;
	}

	public void setTransactionsList(List<AccountTransactionDetails> transactionsList) {
		this.transactionsList = transactionsList;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public Long getTotalElements() {
		return totalElements;
	}

	public void setTotalElements(Long totalElements) {
		this.totalElements = totalElements;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	
	

}
