package com.ibm.inc.demo.ibmincapi.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ACCOUNT_DETAILS")
public class AccountDetails {
	
	
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	@Column(name="ACCOUNT_NUMBER")
	private Long accountNumer;
	
	
	@Column(name="LAST_UPD_BY")
	private LocalDateTime lastUpdBy;
	
	@Column(name="AMOUNT")
	private double amount;
	
	
	public AccountDetails()
	{
		
	}

	public AccountDetails(Long accountNumer, LocalDateTime lastUpdBy, double amount) {
		super();
		this.accountNumer = accountNumer;
		this.lastUpdBy = lastUpdBy;
		this.amount = amount;
	}

	public Long getAccountNumer() {
		return accountNumer;
	}

	public void setAccountNumer(Long accountNumer) {
		this.accountNumer = accountNumer;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	

	public LocalDateTime getLastUpdBy() {
		return lastUpdBy;
	}

	public void setLastUpdBy(LocalDateTime lastUpdBy) {
		this.lastUpdBy = lastUpdBy;
	}

	@Override
	public String toString() {
		return "AccountDetails [accountNumer=" + accountNumer + ", lastUpdBy=" + lastUpdBy + ", amount=" + amount + "]";
	}
	

}
