package com.ibm.inc.demo.ibmincapi.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="ACCOUNT_DETAILS")
public class AccountDetails {
	
	
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	@Column(name="TRANSACTION_ID")
	private Long transactionId;
	
	
	@Column(name="ACCOUNT_NUMBER")
	private String accountNumber;
	
	
	@Column(name="LAST_UPD_BY")
	private LocalDateTime lastUpdBy;
	
	@Column(name="AMOUNT")
	private double amount;
	
	
	public AccountDetails()
	{
		
	}


	public AccountDetails(Long transactionId, String accountNumber, LocalDateTime lastUpdBy, double amount) {
		super();
		this.transactionId = transactionId;
		this.accountNumber = accountNumber;
		this.lastUpdBy = lastUpdBy;
		this.amount = amount;
	}


	public Long getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	public LocalDateTime getLastUpdBy() {
		return lastUpdBy;
	}


	public void setLastUpdBy(LocalDateTime lastUpdBy) {
		this.lastUpdBy = lastUpdBy;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	@Override
	public String toString() {
		return "AccountDetails [transactionId=" + transactionId + ", accountNumber=" + accountNumber + ", lastUpdBy="
				+ lastUpdBy + ", amount=" + amount + "]";
	}

	
	

}
