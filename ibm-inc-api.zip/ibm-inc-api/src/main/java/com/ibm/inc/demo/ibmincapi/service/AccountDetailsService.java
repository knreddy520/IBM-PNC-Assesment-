package com.ibm.inc.demo.ibmincapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.inc.demo.ibmincapi.entity.AccountDetails;
import com.ibm.inc.demo.ibmincapi.exception.AccountNotFoundException;
import com.ibm.inc.demo.ibmincapi.repository.AccountDetailsRepository;

@Service
public class AccountDetailsService {

	
	@Autowired
	AccountDetailsRepository accountDetailsRepository;
	
	
	public AccountDetails getAccountDetails(Long accountNumber)
	{
		return accountDetailsRepository.findById(accountNumber).orElseThrow(() -> new AccountNotFoundException("Account Number does not exist"));
	}
	
}
