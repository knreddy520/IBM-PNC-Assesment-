package com.ibm.inc.demo.ibmincapi.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.inc.demo.ibmincapi.entity.AccountDetails;
import com.ibm.inc.demo.ibmincapi.exception.AccountNotFoundException;
import com.ibm.inc.demo.ibmincapi.repository.AccountDetailsRepository;

@Service
public class AccountDetailsService {

	private static final Logger logger = LogManager.getLogger(AccountDetailsService.class);
	
	@Autowired
	AccountDetailsRepository accountDetailsRepository;
	
	
	public AccountDetails getAccountDetails(String accountNumber)
	{
		
		AccountDetails accountDetailsObj= accountDetailsRepository.findFirstByAccountNumberOrderByLastUpdByDesc(accountNumber);//.orElseThrow(() -> new AccountNotFoundException("Account Number does not exist"));
		
		if (null == accountDetailsObj)
			throw new AccountNotFoundException("Account Number does not exist");
		
		return 	accountDetailsObj;
		
	}
	
}
