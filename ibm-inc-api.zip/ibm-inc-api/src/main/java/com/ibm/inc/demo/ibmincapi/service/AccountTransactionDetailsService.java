package com.ibm.inc.demo.ibmincapi.service;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.stream.Collector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import com.ibm.inc.demo.ibmincapi.entity.AccountTransactionDetails;
import com.ibm.inc.demo.ibmincapi.exception.AccountNotFoundException;
import com.ibm.inc.demo.ibmincapi.pojo.AccountTransactionRequest;
import com.ibm.inc.demo.ibmincapi.pojo.AccountTransactionResponse;
import com.ibm.inc.demo.ibmincapi.repository.AccountTransactionDetailsRepository;

@Service
public class AccountTransactionDetailsService {
	
	@Autowired
	private AccountTransactionDetailsRepository accountTransactionDetailsRepository;
	
	public AccountTransactionResponse getTransactionList(AccountTransactionRequest  accountTransactionRequest,
																Integer pageNo,Integer pageSize,String sortBy)
	{
		AccountTransactionResponse responseObj=new AccountTransactionResponse();
		Page<AccountTransactionDetails> pagedResult=null;
		
		//Step 1
		AccountTransactionRequest targetTransactionRequest=new AccountTransactionRequest();
		
		//Step 2
		validateRequestData(accountTransactionRequest,targetTransactionRequest);
		
		//Step 3
		int scenario=getTransactionFilterScenario(targetTransactionRequest);
		
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
		
		System.out.println("scenario:"+scenario);
		
		switch(scenario) 
		{
		
		case 1:
			pagedResult = accountTransactionDetailsRepository.findAllByAccountNumberAndTransactionTsBetween(targetTransactionRequest.getAccountNumer(),targetTransactionRequest.getFromDate(), targetTransactionRequest.getToDate(),paging);
			break;
		case 2:
			pagedResult = accountTransactionDetailsRepository.findAllByAccountNumberAndTransactionTypeAndTransactionTsBetween(targetTransactionRequest.getAccountNumer(),targetTransactionRequest.getTransactionType(),targetTransactionRequest.getFromDate(), targetTransactionRequest.getToDate(),paging);
			break;
		default:
			pagedResult = accountTransactionDetailsRepository.findByAccountNumber(targetTransactionRequest.getAccountNumer(),paging);
			break;
			
		}
		
		if(pagedResult.hasContent()) {
            responseObj.setTransactionsList(pagedResult.getContent());
       } 	
		
		responseObj.setTotalPages(pagedResult.getTotalPages());
		responseObj.setTotalElements(pagedResult.getTotalElements());
		responseObj.setCurrentPage(pagedResult.getNumber());
		
		
		return responseObj;
	}
	
	
	
	public int getTransactionFilterScenario(AccountTransactionRequest  accountTransactionRequest)
	{
		
		if(accountTransactionRequest.getTransactionType() == null)
		{
			return 1;
		}
		else
		{
			return 2;
		}
		
		
	}
	
	
	@SuppressWarnings("deprecation")
	public void validateRequestData(AccountTransactionRequest accountTransactionRequest,AccountTransactionRequest targetTransactionRequest)
	{
		
		
		//Step 1:
		
		if(null == accountTransactionRequest || StringUtils.isEmpty(accountTransactionRequest.getAccountNumer()) )
		{
			throw new AccountNotFoundException("Account Number does not exist in the request");
		}
		else
		{
			targetTransactionRequest.setAccountNumer(accountTransactionRequest.getAccountNumer());
		}
		
		
		//Step 2: 
		
		if( (null == accountTransactionRequest.getFromDate() && null == accountTransactionRequest.getToDate()) )
		{
			targetTransactionRequest.setFromDate(LocalDateTime.now());
			targetTransactionRequest.setToDate(LocalDateTime.now().plusDays(1));
		}
		else if (null != accountTransactionRequest.getFromDate() && null == accountTransactionRequest.getToDate() )
		{
			targetTransactionRequest.setFromDate(accountTransactionRequest.getFromDate());
			targetTransactionRequest.setToDate(accountTransactionRequest.getFromDate().plusDays(1));
		}
		else if(null == accountTransactionRequest.getFromDate() && null != accountTransactionRequest.getToDate() )
		{
			targetTransactionRequest.setFromDate(accountTransactionRequest.getToDate());
			targetTransactionRequest.setToDate(accountTransactionRequest.getToDate().plusDays(1));
		}
		else if(null != accountTransactionRequest.getFromDate() && null != accountTransactionRequest.getToDate() )
		{
			targetTransactionRequest.setFromDate(accountTransactionRequest.getFromDate());
			targetTransactionRequest.setToDate(accountTransactionRequest.getToDate());
		}
		
		
		
		//Step 3:
		
		 if (targetTransactionRequest.getFromDate().isAfter(targetTransactionRequest.getToDate()) )
			{
				throw new AccountNotFoundException("Start time is greater than End time");
			}
		 
		 
		 //Step 4:
		 
		 if (   StringUtils.isEmpty(accountTransactionRequest.getTransactionType()) )
		 {
			 targetTransactionRequest.setTransactionType(null);
		 }
		 else if ( ("DEPOSIT").equalsIgnoreCase(accountTransactionRequest.getTransactionType()) ) 
		 {
			 targetTransactionRequest.setTransactionType("DEPOSIT");
		 }
		 else if ( ("WITHDRAW").equalsIgnoreCase(accountTransactionRequest.getTransactionType()) )
		 {
			 targetTransactionRequest.setTransactionType("WITHDRAW");
		 }
		 else
		 {
			 targetTransactionRequest.setTransactionType(null);
		 }
		 
		
	}

}
