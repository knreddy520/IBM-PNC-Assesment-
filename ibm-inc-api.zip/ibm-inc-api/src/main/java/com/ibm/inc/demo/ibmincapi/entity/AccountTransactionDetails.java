package com.ibm.inc.demo.ibmincapi.entity;



import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ACCOUNT_TRANSACTION_DETAILS")
public class AccountTransactionDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="TRANSACTION_ID")
	private Long transactionId;
	
	@Column(name="ACCOUNT_NUMBER")
	private String accountNumber;
	
	@Column(name="TRANSACTION_TS")
	private LocalDateTime transactionTs;
	
	@Column(name="TRANSACTION_TYPE")
	private String transactionType;
	
	@Column(name="TRANSACTION_AMOUNT")
	private double transaction_amount;
	
	
	public AccountTransactionDetails()
	{
		
	}
	
	public AccountTransactionDetails(Long transactionId, String accountNumber, LocalDateTime transactionTs, String transactionType,
			double transaction_amount) {
		super();
		this.transactionId=transactionId;
		this.accountNumber = accountNumber;
		this.transactionTs = transactionTs;
		this.transactionType = transactionType;
		this.transaction_amount = transaction_amount;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public LocalDateTime getTransactionTs() {
		return transactionTs;
	}

	public void setTransactionTs(LocalDateTime transactionTs) {
		this.transactionTs = transactionTs;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public double getTransaction_amount() {
		return transaction_amount;
	}

	public void setTransaction_amount(double transaction_amount) {
		this.transaction_amount = transaction_amount;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}
	
	

}
