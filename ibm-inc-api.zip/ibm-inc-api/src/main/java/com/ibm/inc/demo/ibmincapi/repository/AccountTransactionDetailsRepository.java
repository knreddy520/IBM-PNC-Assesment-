package com.ibm.inc.demo.ibmincapi.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ibm.inc.demo.ibmincapi.entity.AccountTransactionDetails;

@Repository
public interface AccountTransactionDetailsRepository extends JpaRepository<AccountTransactionDetails,Long>{

	Page<AccountTransactionDetails> findByAccountNumber(Long accountNumber,Pageable pageable);
	
	Page<AccountTransactionDetails> findAllByAccountNumberAndTransactionTsBetween(Long accountNumber,LocalDateTime transactionTsStart,LocalDateTime transactionTsEnd,Pageable pageable);

	Page<AccountTransactionDetails> findAllByAccountNumberAndTransactionTypeAndTransactionTsBetween(Long accountNumber,String transactionType,LocalDateTime transactionTsStart,LocalDateTime transactionTsEnd,Pageable pageable);

	
	
}
