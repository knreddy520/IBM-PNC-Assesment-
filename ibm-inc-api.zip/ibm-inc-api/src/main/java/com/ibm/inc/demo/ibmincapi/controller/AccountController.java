package com.ibm.inc.demo.ibmincapi.controller;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ibm.inc.demo.ibmincapi.entity.AccountDetails;
import com.ibm.inc.demo.ibmincapi.pojo.AccountTransactionRequest;
import com.ibm.inc.demo.ibmincapi.pojo.AccountTransactionResponse;
import com.ibm.inc.demo.ibmincapi.service.AccountDetailsService;
import com.ibm.inc.demo.ibmincapi.service.AccountTransactionDetailsService;
import com.ibm.inc.demo.ibmincapi.util.JsonUtil;

@RestController
@RequestMapping("/account")
public class AccountController {
	
	private static final Logger logger = LogManager.getLogger(AccountController.class);
		
	@Autowired
	AccountDetailsService accountDetailsService;
	
	@Autowired
	AccountTransactionDetailsService accountTransactionDetailsService;
	
	
	@RequestMapping(method=RequestMethod.GET,value="/getBalance/{accountNumber}")
	public ResponseEntity<AccountDetails> getAccountDetails(@PathVariable String accountNumber)
	{	
		MDC.put("accountNumber",accountNumber);
		logger.info("Request Path parameter:"+accountNumber);
		
		AccountDetails accountDetailsObj= accountDetailsService.getAccountDetails(accountNumber);
		
		
		logger.info("Response JSON:"+JsonUtil.convertoJson(accountDetailsObj));
		
		//Create Header and add it response if any
		MDC.clear();		
		return ResponseEntity.status(HttpStatus.OK).body(accountDetailsObj);
		
		
	}

	@RequestMapping(method=RequestMethod.GET,value="/getTransactionDetails")
	public ResponseEntity<AccountTransactionResponse> getTransactionDetails
	(@RequestBody AccountTransactionRequest  accountTransactionRequest,
     @RequestParam(name="pageNo", required=false, defaultValue = "1") Integer pageNo, 
     @RequestParam(name="pageSize", required=false, defaultValue = "10") Integer pageSize,
     @RequestParam(name="sortBy", required=false, defaultValue = "transactionTs") String sortBy)
	{
		if(!StringUtils.isEmpty(accountTransactionRequest.getAccountNumer()))
		MDC.put("accountNumber",accountTransactionRequest.getAccountNumer().toString());
		
		logger.info("Request Body:"+JsonUtil.convertoJson(accountTransactionRequest));
		logger.info("Request parameters:"+"pageNo="+pageNo+",pageSize="+pageSize+",sortBy="+sortBy);
		
		
		HttpStatus httpStatus=null;
		AccountTransactionResponse accountTransactionResponseObj= accountTransactionDetailsService.getTransactionList(accountTransactionRequest, pageNo, pageSize, sortBy);
		
		
		logger.info("response body:"+JsonUtil.convertoJson(accountTransactionResponseObj));
		
		MDC.clear();
		return ResponseEntity.status(HttpStatus.OK).body(accountTransactionResponseObj);
			
	}
	
	
	
	public String convertoJson(Object obj)
	{
		String jsonResult=null;
		
		if ( null != obj)
		{
			
							
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.registerModule(new JavaTimeModule());
			objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
			
			try {
				jsonResult = objectMapper.writeValueAsString(obj);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Exception while converting POJO to JSON:"+e.getMessage());
			}
		}
		
		return jsonResult;
	}
	

}
