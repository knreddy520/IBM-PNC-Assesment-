package com.ibm.inc.demo.ibmincapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.inc.demo.ibmincapi.entity.AccountDetails;
import com.ibm.inc.demo.ibmincapi.entity.AccountTransactionDetails;
import com.ibm.inc.demo.ibmincapi.pojo.AccountTransactionRequest;
import com.ibm.inc.demo.ibmincapi.pojo.AccountTransactionResponse;
import com.ibm.inc.demo.ibmincapi.service.AccountDetailsService;
import com.ibm.inc.demo.ibmincapi.service.AccountTransactionDetailsService;

@RestController
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	AccountDetailsService accountDetailsService;
	

	@Autowired
	AccountTransactionDetailsService accountTransactionDetailsService;
	
	
	@RequestMapping(method=RequestMethod.GET,value="/getBalance/{accountNumber}")
	public AccountDetails getAccountDetails(@PathVariable Long accountNumber)
	{
		
		return accountDetailsService.getAccountDetails(accountNumber);
	}

	@RequestMapping(method=RequestMethod.GET,value="/getTransactionDetails")
	public AccountTransactionResponse getTransactionDetails
	(@RequestBody AccountTransactionRequest  accountTransactionRequest,
     @RequestParam(name="pageNo", required=false, defaultValue = "1") Integer pageNo, 
     @RequestParam(name="pageSize", required=false, defaultValue = "10") Integer pageSize,
     @RequestParam(name="sortBy", required=false, defaultValue = "transactionTs") String sortBy)
	{
		
		return accountTransactionDetailsService.getTransactionList(accountTransactionRequest, pageNo, pageSize, sortBy);
		
	}
}
