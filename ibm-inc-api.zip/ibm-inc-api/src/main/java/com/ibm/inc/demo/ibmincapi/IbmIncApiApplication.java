package com.ibm.inc.demo.ibmincapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbmIncApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbmIncApiApplication.class, args);
	}

}
